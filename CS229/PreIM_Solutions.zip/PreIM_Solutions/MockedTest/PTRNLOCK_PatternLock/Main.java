import java.util.*;
import java.lang.*;

class Main
{
	static boolean[] exist = new boolean[10]; //kiểm tra xem số i đã được dùng trong mẫu hình hay chưa
	static int[][] mid = new int[10][10]; //mid[a][b]: từ a đến b phải đi qua số mid[a][b], nếu mid[a][b] = 0: không đi qua số nào
	
	public static void main(String[] args) throws Exception {
		//System.setIn(new FileInputStream("src/input.txt"));
		Scanner sc = new Scanner(System.in);

		int T, test_case;
		String str;
		int N;

		//các cặp số mà đường nối giữa chúng phải đi qua số khác:
		mid[1][3] = mid[3][1] = 2;
		mid[1][7] = mid[7][1] = 4;
		mid[3][9] = mid[9][3] = 6;
		mid[7][9] = mid[9][7] = 8;
		mid[1][9] = mid[9][1] = mid[2][8] = mid[8][2] = mid[3][7] = mid[7][3] = mid[4][6] = mid[6][4] = 5;
		
		T = sc.nextInt();
		for (test_case = 1; test_case <= T; test_case++) {
			N = sc.nextInt();
			System.out.print("#" + test_case + " ");
			for (int i = 0; i < N; i++) {
				str = sc.next();
				System.out.print(check(str));
			}
			System.out.println();
		}
	}

	//hàm kiểm tra mẫu hình có hợp lệ hay không
	//trả về 1 nếu hợp lệ, 0 nếu không hợp lệ
	static int check(String str) {
		if (str.length() < 4) {
			return 0; //đk1: phải có ít nhất 4 ký tự
		}

		//khi bắt đầu, chưa có số nào được dùng
		for (int i = 1; i <= 9; i++) {
			exist[i] = false;
		}

		int digit; //số hiện tại
		int prev = 0; //số trước đó, dùng để kiểm tra đường nối 2 số liền nhau
		for (int i = 0; i < str.length(); i++) {
			digit = str.charAt(i) - '0';

			if (exist[digit]) {
				return 0; //đk 2: mỗi điểm chỉ dùng tối đa 1 lần
			}

			exist[digit] = true; //đánh dấu digit đã được dùng

			//đk3: nếu đường nối 2 điểm đi qua 1 điểm khác và điểm đó chưa được dùng
			if (mid[prev][digit] != 0 && !exist[mid[digit][prev]]) {
				return 0;
			}

			prev = digit;
		}
		return 1;
	}
}