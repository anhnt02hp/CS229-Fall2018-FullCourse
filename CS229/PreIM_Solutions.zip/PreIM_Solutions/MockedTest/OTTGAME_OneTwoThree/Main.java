import java.io.FileInputStream;
import java.util.Scanner;

public class Main {

	static final int MAX_N = 12;
	static final int SCISSOR = 1;
	static final int ROCK = 2;
	static final int PAPER = 3;
	
	static int[] chosen = new int[MAX_N]; //choose[i]: lựa chọn của người chơi thứ i, VD choose[1] = 2 tức là người chơi thứ 1 ra búa
	static boolean[] lost = new boolean[MAX_N]; //trạng thái của người thứ i đã thua hay chưa
	static boolean[] exist = new boolean[4]; //kiểm tra có những thế nào đã được ra trong 1 lượt chơi.
	
	public static void main(String[] args) throws Exception {
		//System.setIn(new FileInputStream("src/input.txt"));
		Scanner sc = new Scanner(System.in);
		
		int N, Q, q;
		int T = sc.nextInt();
		int loser; //thế bị thua trong 1 lượt chơi, không cần quan tâm nếu lượt đó hòa

		for (int test_case = 1; test_case <= T; ++test_case) {
			N = sc.nextInt();
			Q = sc.nextInt();

			//bắt đầu 1 test case, chưa có ai bị thua
			for (int i = 1; i <= N; i++) {
				lost[i] = false;
			}
			
			for (q = 0; q < Q; q++) {
				//bắt đầu 1 lượt chơi, chưa thế nào được chọn
				exist[SCISSOR] = exist[ROCK] = exist[PAPER] = false;
				
				for (int i = 1; i <= N; i++) {
					chosen[i] = sc.nextInt(); //nhập các lựa chọn cùa người chơi từ input
					
					//chỉ xét đến lựa chọn của 1 người khi người đó chưa thua
					if (!lost[i]) {
						exist[chosen[i]] = true;
					}
				}
				
				//nếu có cả 3 thế => hòa
				if (exist[SCISSOR] && exist[ROCK] && exist[PAPER]) {
					continue;
				}
				
				//nếu có đúng 2 thế => chọn ra thế thua
				if (exist[SCISSOR] && exist[ROCK]) {
					loser = SCISSOR;
				} else if (exist[ROCK] && exist[PAPER]) {
					loser = ROCK;
				} else if (exist[PAPER] && exist[SCISSOR]) {
					loser = PAPER;
				} else { //nếu chỉ có 1 thế => hòa
					continue;
				}
				
				//nếu lượt chơi không bị hòa, tìm những người đã chọn thế thua và đánh dấu họ là đã thua 
				for (int i = 1; i <= N; i++) {
					if (chosen[i] == loser) {
						lost[i] = true;	
					}
				}
			}

			//in ra những người chưa thua
			System.out.print("#" + test_case + " ");
			for (int i = 1; i <= N; i++) {
				if (!lost[i]) {
					System.out.print(i + " ");
				}
			}
			System.out.println("");			
		}
	}
}