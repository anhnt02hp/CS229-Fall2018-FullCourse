#include <stdio.h>

#define MAX_N 12
#define SCISSOR 1
#define ROCK 2
#define PAPER 3

int choose[MAX_N]; //choose[i]: lựa chọn của người chơi thứ i, VD choose[1] = 2 tức là người chơi thứ 1 ra búa
bool lost[MAX_N]; //trạng thái của người thứ i đã thua hay chưa
bool exist[4]; //kiểm tra có những thế nào đã được ra trong 1 lượt chơi.

int main() {
	//freopen("input.txt", "r", stdin);
	int T, test_case;
	int N, Q, q;
	int loser; //thế bị thua trong 1 lượt chơi, không cần quan tâm nếu lượt đó hòa

	scanf("%d", &T);
	for (test_case = 1; test_case <= T; ++test_case) {
		scanf("%d%d", &N, &Q);

		//bắt đầu 1 test case, chưa có ai bị thua
		for (int i = 1; i <= N; i++)
			lost[i] = false;

		for (q = 0; q < Q; q++) {
			//bắt đầu 1 lượt chơi, chưa thế nào được chọn
			exist[SCISSOR] = exist[ROCK] = exist[PAPER] = false;

			for (int i = 1; i <= N; i++) {
				scanf("%d", &choose[i]); //nhập các lựa chọn cùa người chơi từ input
				if (!lost[i]) //chỉ xét đến lựa chọn của 1 người khi người đó chưa thua
					exist[choose[i]] = true;
			}

			//nếu có cả 3 thế => hòa
			if (exist[SCISSOR] && exist[ROCK] && exist[PAPER])
				continue;

			//nếu có đúng 2 thế => chọn ra thế thua
			if (exist[SCISSOR] && exist[ROCK])
				loser = SCISSOR;
			else if (exist[ROCK] && exist[PAPER])
				loser = ROCK;
			else if (exist[PAPER] && exist[SCISSOR])
				loser = PAPER;
			else //nếu chỉ có 1 thế => hòa
				continue;

			//nếu lượt chơi không bị hòa, tìm những người đã chọn thế thua và đánh dấu họ là đã thua 
			for (int i = 1; i <= N; i++)
				if (choose[i] == loser)
					lost[i] = true;
		}

		printf("#%d ", test_case);

		//in ra những người chưa thua
		for (int i = 1; i <= N; i++)
			if (!lost[i])
				printf("%d ", i);
		printf("\n");
	}
	return 0;
}